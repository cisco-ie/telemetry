slice from 200204_2108_ecmp 100 1000
spine3 loopback changed