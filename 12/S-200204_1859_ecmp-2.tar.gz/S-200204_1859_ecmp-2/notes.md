slice from 200204_1859_ecmp 750 1500
spine3 loopback restored