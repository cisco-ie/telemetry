slice from 200206_1450_ecmp 50 1000
spine3 loopback changed