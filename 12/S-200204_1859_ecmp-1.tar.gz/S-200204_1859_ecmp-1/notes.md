slice from 200204_1859_ecmp 50 1000
spine3 loopback changed