slice from 200206_1416_iflap 650 1650
leaf4 Hu/12 enabled