slice from 200121_0507_ecmp 30 1400
ecmp balance break, check spine3