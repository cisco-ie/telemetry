slice from 200202_2014_evtmix 800 1600
check spine3