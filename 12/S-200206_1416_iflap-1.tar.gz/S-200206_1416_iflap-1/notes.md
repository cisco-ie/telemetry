slice from 200206_1416_iflap 50 800
leaf4 Hu/12 disabled