slice from 200206_1626_evtmix 50 850
leaf7 Hu/11 disabled