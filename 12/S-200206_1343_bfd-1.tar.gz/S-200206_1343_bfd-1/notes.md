slice from 200206_1343_bfd 850 1750
spine4 break bfd, data-rate changes with 100s delay