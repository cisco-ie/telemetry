slice from 200202_2121_evtmix 750 1400
leaf4 Hu/12 enabled