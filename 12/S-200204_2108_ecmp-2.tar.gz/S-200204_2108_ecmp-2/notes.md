slice from 200204_2108_ecmp 900 1700
spine3 loopback restored