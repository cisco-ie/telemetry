slice from 200202_2228_evtmix 650 1400
leaf4 Hu/4 enabled