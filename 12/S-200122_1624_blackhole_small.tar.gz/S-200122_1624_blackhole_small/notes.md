slice from 200122_1624_blackhole 30 1300
