slice from 200124_0247_bfd 30 1300
leaf7 Hu/22 restored with a 40sec delay