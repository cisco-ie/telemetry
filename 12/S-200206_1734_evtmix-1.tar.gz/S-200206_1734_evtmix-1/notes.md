slice from 200206_1734_evtmix 50 850
leaf7 Hu/15 disabled