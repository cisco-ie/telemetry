slice from 200204_1932_blackhole 50 1000
