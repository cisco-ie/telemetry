slice from 200204_2142_blackhole 900 1600
