slice from 200121_0507_ecmp 900 1800
ecmp balance restore, check spine3