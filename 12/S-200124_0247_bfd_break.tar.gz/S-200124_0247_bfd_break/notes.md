slice from 200124_0247_bfd 950 1800
see leaf7 Hu/22