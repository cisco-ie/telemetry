slice from 200202_1940_bfd 950 1600
spine4 break_bfd