slice from 200122_1729_iflap 1000 1800
see leaf4-spine1 link