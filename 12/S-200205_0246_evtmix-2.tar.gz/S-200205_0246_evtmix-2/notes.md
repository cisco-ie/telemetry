slice from 200205_0246_evtmix 650 1400
leaf7 Hu/14 enabled