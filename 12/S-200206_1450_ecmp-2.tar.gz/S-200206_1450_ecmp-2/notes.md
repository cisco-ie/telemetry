slice from 200206_1450_ecmp 850 1750
spine3 loopback restored