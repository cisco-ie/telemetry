slice from 200205_0030_evtmix 650 1400
leaf7 Hu/1 enabled