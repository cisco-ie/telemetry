slice from 200206_1523_blackhole 50 1000
