slice from 200202_2047_evtmix 50 850
leaf4 Hu/10 disabled