slice from 200121_0836_blackhole 30 1400
blackhole, check leaf4