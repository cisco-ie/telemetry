slice from 200204_1825_bfd 750 1500
spine4 break bfd