slice from 200122_1729_iflap 360 1000
see leaf4-spine1 link