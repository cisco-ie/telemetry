slice from 200202_2302_evtmix 650 1400
leaf4 Hu/18 enabled