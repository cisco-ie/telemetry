slice from 200206_1235_ecmp 900 1800
spine3 loopback restored