slice from 200205_0104_evtmix 60 800
leaf7 Hu/0 disabled