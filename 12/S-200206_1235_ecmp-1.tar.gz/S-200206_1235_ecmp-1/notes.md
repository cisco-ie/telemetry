slice from 200206_1235_ecmp 50 1000
spine3 loopback changed