slice from 200121_0803_ecmp 30 1200
ecmp balance break, check spine3, leaf4