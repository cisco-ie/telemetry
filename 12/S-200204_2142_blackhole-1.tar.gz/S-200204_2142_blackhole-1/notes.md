slice from 200204_2142_blackhole 100 1000
