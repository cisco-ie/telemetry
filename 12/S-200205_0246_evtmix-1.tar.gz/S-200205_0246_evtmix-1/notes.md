slice from 200205_0246_evtmix 50 750
leaf7 Hu/14 disabled