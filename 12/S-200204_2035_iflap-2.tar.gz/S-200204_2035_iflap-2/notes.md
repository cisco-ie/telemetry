slice from 200204_2035_iflap 650 1400
leaf4 Hu/17 enabled