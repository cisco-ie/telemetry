slice from 200121_0731_iflap 30 1000
