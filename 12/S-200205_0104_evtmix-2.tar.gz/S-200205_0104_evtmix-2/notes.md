slice from 200205_0104_evtmix 670 1500
leaf7 Hu/0 enabled