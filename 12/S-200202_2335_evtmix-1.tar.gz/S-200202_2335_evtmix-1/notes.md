slice from 200202_2335_evtmix 50 800
leaf4 Hu/4 disabled