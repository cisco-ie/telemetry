slice from 200204_1932_blackhole 850 1500
