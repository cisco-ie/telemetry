slice from 200202_1907_blackhole 800 1700
