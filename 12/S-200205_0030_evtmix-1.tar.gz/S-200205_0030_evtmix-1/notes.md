slice from 200205_0030_evtmix 50 850
leaf7 Hu/1 disabled